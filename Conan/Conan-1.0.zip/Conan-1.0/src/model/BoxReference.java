package model;

//Used to indicate whether a new row should be inserted in the row before or after a reference rowr
//This is very poorly named...
public enum BoxReference{
	BEFORE, AFTER
}