package model;

import java.io.Serializable;

public interface ProofEntry extends Serializable{
	public Box getParent();
}
