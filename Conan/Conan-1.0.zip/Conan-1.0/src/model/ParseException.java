package model;
public class ParseException extends RuntimeException{

	public ParseException(String msg){
        super(msg);
    }
}



