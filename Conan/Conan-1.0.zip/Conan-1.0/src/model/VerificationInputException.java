package model;

public class VerificationInputException extends RuntimeException {
    public VerificationInputException(String msg){
        super(msg);
    }
}
