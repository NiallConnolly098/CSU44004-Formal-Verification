package view;
import javafx.scene.control.Tab;
public interface View {
    Tab getTab();
    void focusFirst();
}
