# Conan
A proof editor for first order logic
